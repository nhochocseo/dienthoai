<div class="col-md-9 right">
    <?php 
        include("slideshow.php");
     ?>
    <ul class="nav nav-tabs">
        <li class="active"><a data-toggle="tab" href="#home">Sản Phảm Mới</a></li>
        <li><a data-toggle="tab" href="#menu1">Sản Phẩm Bán Chạy</a></li>
        <li><a data-toggle="tab" href="#menu2">Sản Phảm Cũ</a></li>
    </ul>
    <div class="tab-content">
        <div id="home" class="tab-pane fade in active">
            <div class="icy-link-posts">
              <div class="icy-box-content">
            <div class="icy-box-img">
                <img src="/images/san-pham/11.png" alt="">
            </div>
            <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                            <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
            <ul class="icy-box-caption">
                <li>
                    <a href="">Mua ngay</a>
                </li>
            </ul>
        </div>
                <div class="icy-box-content">
                    <div class="icy-box-img">
                        <img src="/images/san-pham/8.png" alt="">
                    </div>
                    <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
                    <ul class="icy-box-caption">
                        <li>
                            <a href="">Mua ngay</a>
                        </li>
                    </ul>
                </div>
                <div class="icy-box-content">
                    <div class="icy-box-img">
                        <img src="/images/san-pham/9.png" alt="">
                    </div>
                    <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
                    <ul class="icy-box-caption">
                        <li>
                            <a href="">Mua ngay</a>
                        </li>
                    </ul>
                </div>
                <div class="icy-box-content">
                    <div class="icy-box-img">
                        <img src="/images/san-pham/10.png" alt="">
                    </div>
                    <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
                    <ul class="icy-box-caption">
                        <li>
                            <a href="">Mua ngay</a>
                        </li>
                    </ul>
                </div>
                <div class="icy-box-content">
            <div class="icy-box-img">
                <img src="/images/san-pham/11.png" alt="">
            </div>
            <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                            <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
            <ul class="icy-box-caption">
                <li>
                    <a href="">Mua ngay</a>
                </li>
            </ul>
        </div>
        
                <div class="icy-box-content">
                    <div class="icy-box-img">
                        <img src="/images/san-pham/11.png" alt="">
                    </div>
                    <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                            <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
                    <ul class="icy-box-caption">
                        <li>
                            <a href="">Mua ngay</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="menu1" class="tab-pane fade">
            <div class="icy-link-posts">
                <div class="icy-box-content">
                    <div class="icy-box-img">
                        <img src="/images/san-pham/1.png" alt="">
                    </div>
                    <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
                    <ul class="icy-box-caption">
                        <li>
                            <a href="">Mua ngay</a>
                        </li>
                    </ul>
                </div>
                <div class="icy-box-content">
                    <div class="icy-box-img">
                        <img src="/images/san-pham/2.png" alt="">
                    </div>
                    <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
                    <ul class="icy-box-caption">
                        <li>
                            <a href="">Mua ngay</a>
                        </li>
                    </ul>
                </div>
                <div class="icy-box-content">
                    <div class="icy-box-img">
                        <img src="/images/san-pham/3.png" alt="">
                    </div>
                    <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
                    <ul class="icy-box-caption">
                        <li>
                            <a href="">Mua ngay</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="menu2" class="tab-pane fade">
            <div class="icy-link-posts">
              <div class="icy-box-content">
                    <div class="icy-box-img">
                        <img src="/images/san-pham/7.png" alt="">
                    </div>
                    <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
                    <ul class="icy-box-caption">
                        <li>
                            <a href="">Mua ngay</a>
                        </li>
                    </ul>
                </div>
                <div class="icy-box-content">
                    <div class="icy-box-img">
                        <img src="/images/san-pham/4.png" alt="">
                    </div>
                    <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
                    <ul class="icy-box-caption">
                        <li>
                            <a href="">Mua ngay</a>
                        </li>
                    </ul>
                </div>
                <div class="icy-box-content">
                    <div class="icy-box-img">
                        <img src="/images/san-pham/5.png" alt="">
                    </div>
                    <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
                    <ul class="icy-box-caption">
                        <li>
                            <a href="">Mua ngay</a>
                        </li>
                    </ul>
                </div>
                <div class="icy-box-content">
                    <div class="icy-box-img">
                        <img src="/images/san-pham/6.png" alt="">
                    </div>
                    <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
                    <ul class="icy-box-caption">
                        <li>
                            <a href="">Mua ngay</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
        <h4 class="icy-title-sp">
        <span>Sản Phảm Bán Chạy</span>
     </h4>
    <div class="icy-link-posts">
        <div class="icy-box-content">
            <div class="icy-box-img">
                <img src="/images/san-pham/1.png" alt="">
            </div>
            <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
            <ul class="icy-box-caption">
                <li>
                    <a href="">Mua ngay</a>
                </li>
            </ul>
        </div>
        <div class="icy-box-content">
            <div class="icy-box-img">
                <img src="/images/san-pham/2.png" alt="">
            </div>
            <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
            <ul class="icy-box-caption">
                <li>
                    <a href="">Mua ngay</a>
                </li>
            </ul>
        </div>
        <div class="icy-box-content">
            <div class="icy-box-img">
                <img src="/images/san-pham/3.png" alt="">
            </div>
            <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
            <ul class="icy-box-caption">
                <li>
                    <a href="">Mua ngay</a>
                </li>
            </ul>
        </div>
        <div class="icy-box-content">
            <div class="icy-box-img">
                <img src="/images/san-pham/4.png" alt="">
            </div>
            <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
            <ul class="icy-box-caption">
                <li>
                    <a href="">Mua ngay</a>
                </li>
            </ul>
        </div>
        <div class="icy-box-content">
            <div class="icy-box-img">
                <img src="/images/san-pham/5.png" alt="">
            </div>
            <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
            <ul class="icy-box-caption">
                <li>
                    <a href="">Mua ngay</a>
                </li>
            </ul>
        </div>
        <div class="icy-box-content">
            <div class="icy-box-img">
                <img src="/images/san-pham/6.png" alt="">
            </div>
            <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
            <ul class="icy-box-caption">
                <li>
                    <a href="">Mua ngay</a>
                </li>
            </ul>
        </div>
        <div class="icy-box-content">
            <div class="icy-box-img">
                <img src="/images/san-pham/7.png" alt="">
            </div>
            <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
            <ul class="icy-box-caption">
                <li>
                    <a href="">Mua ngay</a>
                </li>
            </ul>
        </div>
        <div class="icy-box-content">
            <div class="icy-box-img">
                <img src="/images/san-pham/8.png" alt="">
            </div>
            <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
            <ul class="icy-box-caption">
                <li>
                    <a href="">Mua ngay</a>
                </li>
            </ul>
        </div>
        <div class="icy-box-content">
            <div class="icy-box-img">
                <img src="/images/san-pham/9.png" alt="">
            </div>
            <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
            <ul class="icy-box-caption">
                <li>
                    <a href="">Mua ngay</a>
                </li>
            </ul>
        </div>
        <div class="icy-box-content">
            <div class="icy-box-img">
                <img src="/images/san-pham/10.png" alt="">
            </div>
            <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                    <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
            <ul class="icy-box-caption">
                <li>
                    <a href="">Mua ngay</a>
                </li>
            </ul>
        </div>
        <div class="icy-box-content">
            <div class="icy-box-img">
                <img src="/images/san-pham/11.png" alt="">
            </div>
            <h3 class="icy-box-title">
                <a href="#">Demo Link post</a>
                <span class="icy-box-price">
                            <i class="icy-icon-price"></i>
                    Giá : 10000000 VNĐ
                </span>
            </h3>
            <ul class="icy-box-caption">
                <li>
                    <a href="">Mua ngay</a>
                </li>
            </ul>
        </div>
    </div>
</div>
