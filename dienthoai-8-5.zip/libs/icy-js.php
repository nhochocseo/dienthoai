// This file does not know what to do ! reverse play for fun !
<?php
header("Content-Type: text/javascript;charset=UTF-8");
require('../bootstrap/js/jquery.js');
require('../bootstrap/js/bootstrap.min.js');
require('../bootstrap/js/jquery-2.2.3.min.js');
require('../bootstrap/js/icy-jquery.min.js');
require('../bootstrap/js/icy-dropdown.js');
?>