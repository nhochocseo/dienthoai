<?php
header("Content-type: text/css; charset=utf-8");
require('../style.css');
require('../bootstrap/css/bootstrap.min.css');
require('../bootstrap/css/bootstrap-theme.min.css');
require('../bootstrap/font-awesome/css/font-awesome.min.css');
?>