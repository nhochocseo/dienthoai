<div class="row">
<?php
	include("content.php");
	include("sidebar.php");
?>
</div>