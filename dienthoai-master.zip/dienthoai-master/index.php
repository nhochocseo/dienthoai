<?php 
include("head.php");
include("content.php");
include("footer.php");
 ?>

